# My_CSVtoJSON_Converter

my_csvtojson_converter é um simples conversor de arquivos .csv para o formato .json e vice-versa.

As funções recebem, basicamente: um input contendo um Path (caminho do arquivo) e um delimitador em formato string (, ou ;).


## Função leitura de .csv

*'leitor_csv(input_path: Path, delimiter: str = ',' or ';')'

